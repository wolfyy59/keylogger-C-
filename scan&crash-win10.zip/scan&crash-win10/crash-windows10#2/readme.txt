
May 11, 2021
Windows Server, version 20H2 (Server Core Installation)
-
Remote Code Execution
Critical
5003173
Security Update
CVE-2021-31166
May 11, 2021
Windows 10 Version 20H2 for ARM64-based Systems
-
Remote Code Execution
Critical
5003173
Security Update
CVE-2021-31166
May 11, 2021
Windows 10 Version 20H2 for 32-bit Systems
-
Remote Code Execution
Critical
5003173
Security Update
CVE-2021-31166
May 11, 2021
Windows 10 Version 20H2 for x64-based Systems
-
Remote Code Execution
Critical
5003173
Security Update
CVE-2021-31166
May 11, 2021
Windows Server, version 2004 (Server Core installation)
-
Remote Code Execution
Critical
5003173
Security Update
CVE-2021-31166
May 11, 2021
Windows 10 Version 2004 for x64-based Systems
-
Remote Code Execution
Critical
5003173
Security Update
CVE-2021-31166
May 11, 2021
Windows 10 Version 2004 for ARM64-based Systems
-
Remote Code Execution
Critical
5003173
Security Update
CVE-2021-31166
May 11, 2021
Windows 10 Version 2004 for 32-bit Systems
-
Remote Code Execution
Critical
5003173
Security Update
CVE-2021-31166
execute bash script and then write the target ip adress
http://192.168.1.36/
