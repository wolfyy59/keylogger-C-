# CVE-2021-31166
simple bash script for exploit CVE-2021-31166

![Alt text](CVE-2021-31166.gif)
