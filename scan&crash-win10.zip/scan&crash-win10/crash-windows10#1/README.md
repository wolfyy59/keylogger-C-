# Unauthenticated CVE-2020-0796 Proof-of-Concept

All the proofs-of-concept scripts I've seen at this point have required both a username and a password. Therefore I decided to post my own PoC. It's nothing fancy, but it works.

It doesn't require any additional modules and works with Python 3.

Usage:
`python3 crash.py 192.168.0.2`
