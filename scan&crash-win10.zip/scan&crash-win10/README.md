# cve-2020-0796-scanner
This project is base on [SMBGhost](https://github.com/ollypwn/SMBGhost) which is used for scanning CVE-2020-0796 - SMBv3 RCE vulnerability. only add batch scanning function.

# Usage
```
python3 cve-2020-0796-scanner.py -t <IP/MASK>
```

# Workarounds
```
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" DisableCompression -Type DWORD -Value 1 -Force
```
> This project(https://github.com/T13nn3s/CVE-2020-0976) provide a auto script to mitigate the risk which will be easier for endpoint user to implement.
